The official and MIT licensed FreeRTOS ports for RISC-V are located in the following directories:
\FreeRTOS\Source\portable\GCC\RISC-V
\FreeRTOS\Source\portable\IAR\RISC-V

Also so https://www.FreeRTOS.org/Using-FreeRTOS-on-RISC-V.html
