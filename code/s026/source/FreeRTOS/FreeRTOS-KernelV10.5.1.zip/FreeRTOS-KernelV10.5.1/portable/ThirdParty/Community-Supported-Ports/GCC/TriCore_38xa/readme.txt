Compile the project with the "-fdollars-in-identifiers" option!!
