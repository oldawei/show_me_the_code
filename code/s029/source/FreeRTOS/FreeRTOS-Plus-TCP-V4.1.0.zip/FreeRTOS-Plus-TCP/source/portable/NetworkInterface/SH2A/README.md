## Disclaimer :

Please note that SH2A port has not been tested with IPv6, Multiple endpoint and interfaces which are supported by the latest TCP release V4.0.0. This needs to be used with caution in IPv6 environment as there can be potential compatibility issues.


## Last Git Release :

You can find the last release supporting this port on our GitHub repository here : [V3.1.0](https://github.com/FreeRTOS/FreeRTOS-Plus-TCP/releases/tag/V3.1.0). Visit the mentioned link to access the repository and download the version supporting SH2A port to use it.


## Contribution and Support :

If you are interested in contributing to the development of this port or have any question regarding this port, feel free to post on [FreeRTOS forum](https://forums.freertos.org/). Your inputs are valuable to us and we encourage collaboration and discussion within the community.
