This directory contains include files used by the CBMC proofs:
* cbmc.h defines some macros used in the proof test harnesses
