The proofs in this directory guarantee together that
ARPRefreshCacheEntry is memory safe independent
of the configuration value of
ipconfigARP_STORES_REMOTE_ADDRESSES.
