FreeRTOS_PrintARPCache_harness.c is memory safe,
assuming vLoggingPrintf is correct and memory safe.

FreeRTOS_PrintARPCache does not use multiple configurations.
